<?php
$language = "fr-fr"; // language package use
$host = "localhost"; // Host name db
$user = "root"; // User db
$password = "Pazdelaputa13"; // Password db
$dbname = "html"; // db name webapp
?>
