<?php 
$language = "fr-fr";
$host = "localhost";
$user = "root";
$password = "Pazdelaputa13";
$dbname = "html2";
?> 
